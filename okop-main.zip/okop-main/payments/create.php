<?php

include("conexao.php");

session_start();
$is_localhost = ($_SERVER['REMOTE_ADDR'] === '127.0.0.1' || $_SERVER['REMOTE_ADDR'] === '::1');
$captcha_response = isset($_REQUEST['captcha']) ? $_REQUEST['captcha'] : null;

if ($is_localhost) {
    $captcha_response = 'blablabla';
}

if (!isset($captcha_response) or $captcha_response == '') {
    exit;
}

if (!$is_localhost && $captcha_response) {
    $captcha_secret = '0x4AAAAAAAkv31gTVxo1gJkheOmwXTH-u7Q';
    $captcha_url = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
    $data = [
        'secret' => $captcha_secret,
        'response' => $captcha_response
    ];

    $ch = curl_init($captcha_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    $captcha_result = curl_exec($ch);
    curl_close($ch);

    $captcha_result = json_decode($captcha_result, true);

    if (!$captcha_result['success']) {
        echo json_encode(['status' => 'error', 'message' => 'CAPTCHA verification failed']);
        exit;
    }
}

function gerarZoneIdUnico() {
    $ip = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $timestamp = microtime(true);
    $random_number = bin2hex(random_bytes(16));
    $unique_data = $ip . $user_agent . $timestamp . $random_number;
    $zone_id = hash('sha256', $unique_data);
    return $zone_id;
}

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);
$email = 'test@syncdata.org';
$zone_id = gerarZoneIdUnico();

if (empty($usuario) or empty($senha)) {
    $json = array("success" => false, "message" => "Preencha os Dados.");
    echo json_encode($json);
    exit();
}

// Verifica se o usuário já existe
$sql_check = "SELECT id FROM usuarios WHERE usuario = '$usuario'";
$result_check = mysqli_query($conexao, $sql_check);

if (mysqli_num_rows($result_check) > 0) {
    $json = array("success" => false, "message" => "Usuário já existe.");
    echo json_encode($json);
    exit();
}

$dias = date('Y-m-d', strtotime('+1 day'));

$sql_insert = "INSERT INTO usuarios (usuario, senha, email, dias, data_acesso, nivel, zone_id) 
               VALUES ('$usuario', '$senha', '$email', '$dias', NOW(), 0, '$zone_id')";
$execute_insert = mysqli_query($conexao, $sql_insert);

if ($execute_insert) {
    $json = array("success" => true, "message" => "Usuário registrado com sucesso");
} else {
    $json = array("success" => false, "message" => "Erro ao registrar usuário");
}

echo json_encode($json);

?>